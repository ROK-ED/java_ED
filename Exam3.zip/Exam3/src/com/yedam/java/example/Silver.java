package com.yedam.java.example;

public class Silver extends Member {

	public Silver(int record) {
		super(record);
		grade="SILVER";
	}

}
