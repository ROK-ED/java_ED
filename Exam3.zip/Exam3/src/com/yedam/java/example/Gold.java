package com.yedam.java.example;

public class Gold extends Member{

	public Gold(int record) {
		super(record);
		grade="GOLD";
	}

	}
